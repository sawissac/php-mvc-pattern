<?php
class ImMath
{
    public $PI = 3.14;
}

$m = new ImMath();

print($m->PI);