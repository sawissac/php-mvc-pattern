<?php


return [
    '/'=>'home.php',
    '/notes' => 'notes.php',
    '/login' => 'login.php',
    '/register' => 'register.php'
];